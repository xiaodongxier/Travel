<!--
 * @Date: 2020-05-25 14:19:33
 * @LastEditTime: 2020-07-06 15:52:39
 * @Author: WangYongJie
 * @Work-email: wangyongjie2@gome.com.cn
 * @Private-email: admin@xiaodongxier.com
--> 
# travel

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).